When loading the map into your game world, ensure the following is true:
Width 9400px
Height 5800px
Grid 200px
Scale 1m(eter)